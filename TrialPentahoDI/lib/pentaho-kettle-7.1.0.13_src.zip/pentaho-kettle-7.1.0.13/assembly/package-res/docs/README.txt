All available (free) documentation for Pentaho Data Integration can be found on our wiki:

   http://wiki.pentaho.com/display/EAI/

